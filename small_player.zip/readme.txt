一个godot engine 做的小游戏

可以发布android，pc，h5，ios没试（应该也行）

godot版本2.1.4

下载下来解压后用godot打开

taptap：https://www.taptap.com/app/78576

